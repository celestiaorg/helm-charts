{{- define "common-celestia-node.full_config.toml" -}}
[Node]
  StartupTimeout = "{{ .Values.node.config.full.configtoml.Node.StartupTimeout }}"
  ShutdownTimeout = "{{ .Values.node.config.full.configtoml.Node.ShutdownTimeout }}"
[Core]
  IP = "{{ .Values.node.config.full.configtoml.Core.IP }}"
  Port = "{{ .Values.node.config.full.configtoml.Core.Port }}"
  TLSEnabled = {{ .Values.node.config.full.configtoml.Core.TLSEnabled }}
  XTokenPath = "{{ .Values.node.config.full.configtoml.Core.XTokenPath }}"
  AdditionalCoreEndpoints = {{ .Values.node.config.full.configtoml.Core.AdditionalCoreEndpoints }}
[State]
  DefaultKeyName = "{{ .Values.node.config.full.configtoml.State.DefaultKeyName }}"
  DefaultBackendName = "{{ .Values.node.config.full.configtoml.State.DefaultBackendName }}"
  EstimatorAddress = "{{ .Values.node.config.full.configtoml.State.EstimatorAddress }}"
  EnableEstimatorTLS = {{ .Values.node.config.full.configtoml.State.EnableEstimatorTLS }}
  TxWorkerAccounts = {{ .Values.node.config.bridge.configtoml.State.TxWorkerAccounts }}
[P2P]
  ListenAddresses = [{{ range $index, $element := .Values.node.config.full.configtoml.P2P.ListenAddresses }}{{ if $index }}, {{ end }}"{{ $element }}"{{ end }}]
  AnnounceAddresses = {{ .Values.node.config.full.configtoml.P2P.AnnounceAddresses }}
  NoAnnounceAddresses = [{{ range $index, $element := .Values.node.config.full.configtoml.P2P.NoAnnounceAddresses }}{{ if $index }}, {{ end }}"{{ $element }}"{{ end }}]
  MutualPeers = {{ .Values.node.config.full.configtoml.P2P.MutualPeers }}
  PeerExchange = {{ .Values.node.config.full.configtoml.P2P.PeerExchange }}
  [P2P.ConnManager]
    Low = {{ printf "%.0f" .Values.node.config.full.configtoml.P2P.ConnManager.Low }}
    High = {{ printf "%.0f" .Values.node.config.full.configtoml.P2P.ConnManager.High }}
    GracePeriod = "{{ .Values.node.config.full.configtoml.P2P.ConnManager.GracePeriod }}"
[RPC]
  Address = "{{ .Values.node.config.full.configtoml.RPC.Address }}"
  Port = "{{ .Values.node.config.full.configtoml.RPC.Port }}"
  SkipAuth = {{ .Values.node.config.full.configtoml.RPC.SkipAuth }}
  [RPC.CORS]
    Enabled = {{ .Values.node.config.full.configtoml.RPC.CORS.Enabled }}
    AllowedOrigins = {{ .Values.node.config.full.configtoml.RPC.CORS.AllowedOrigins }}
    AllowedHeaders = {{ .Values.node.config.full.configtoml.RPC.CORS.AllowedHeaders }}
    AllowedMethods = {{ .Values.node.config.full.configtoml.RPC.CORS.AllowedMethods }}
[Share]
  BlockStoreCacheSize = {{ printf "%.0f" .Values.node.config.full.configtoml.Share.BlockStoreCacheSize }}
  UseShareExchange = {{ .Values.node.config.full.configtoml.Share.UseShareExchange }}
  UseBitswap = {{ .Values.node.config.full.configtoml.Share.UseBitswap }}
  [Share.EDSStoreParams]
    RecentBlocksCacheSize = {{ printf "%.0f" .Values.node.config.full.configtoml.Share.EDSStoreParams.RecentBlocksCacheSize }}
  [Share.ShrexClient]
    ReadTimeout = "{{ .Values.node.config.full.configtoml.Share.ShrexClient.ReadTimeout }}"
    WriteTimeout = "{{ .Values.node.config.full.configtoml.Share.ShrexClient.WriteTimeout }}"
  [Share.ShrexServer]
    ReadTimeout = "{{ .Values.node.config.full.configtoml.Share.ShrexServer.ReadTimeout }}"
    WriteTimeout = "{{ .Values.node.config.full.configtoml.Share.ShrexServer.WriteTimeout }}"
    HandleRequestTimeout = "{{ .Values.node.config.full.configtoml.Share.ShrexServer.HandleRequestTimeout }}"
    ConcurrencyLimit = {{ printf "%.0f" .Values.node.config.full.configtoml.Share.ShrexServer.ConcurrencyLimit }}
  [Share.PeerManagerParams]
    PoolValidationTimeout = "{{ .Values.node.config.full.configtoml.Share.PeerManagerParams.PoolValidationTimeout }}"
    PeerCooldown = "{{ .Values.node.config.full.configtoml.Share.PeerManagerParams.PeerCooldown }}"
    GcInterval = "{{ .Values.node.config.full.configtoml.Share.PeerManagerParams.GcInterval }}"
    EnableBlackListing = {{ .Values.node.config.full.configtoml.Share.PeerManagerParams.EnableBlackListing }}
  [Share.Discovery]
    PeersLimit = {{ printf "%.0f" .Values.node.config.full.configtoml.Share.Discovery.PeersLimit }}
    AdvertiseInterval = "{{ .Values.node.config.full.configtoml.Share.Discovery.AdvertiseInterval }}"
[Header]
  TrustedPeers = {{ .Values.node.config.full.configtoml.Header.TrustedPeers }}
  [Header.Store]
    StoreCacheSize = {{ printf "%.0f" .Values.node.config.full.configtoml.Header.Store.StoreCacheSize }}
    IndexCacheSize = {{ printf "%.0f" .Values.node.config.full.configtoml.Header.Store.IndexCacheSize }}
    WriteBatchSize = {{ printf "%.0f" .Values.node.config.full.configtoml.Header.Store.WriteBatchSize }}
  [Header.Syncer]
    PruningWindow = "{{ .Values.node.config.full.configtoml.Header.Syncer.PruningWindow }}"
    SyncFromHash = "{{ .Values.node.config.full.configtoml.Header.Syncer.SyncFromHash }}"
    SyncFromHeight = {{ printf "%.0f" .Values.node.config.full.configtoml.Header.Syncer.SyncFromHeight }}
  [Header.Server]
    WriteDeadline = "{{ .Values.node.config.full.configtoml.Header.Server.WriteDeadline }}"
    ReadDeadline = "{{ .Values.node.config.full.configtoml.Header.Server.ReadDeadline }}"
    RequestTimeout = "{{ .Values.node.config.full.configtoml.Header.Server.RequestTimeout }}"
  [Header.Client]
    MaxHeadersPerRangeRequest = {{ printf "%.0f" .Values.node.config.full.configtoml.Header.Client.MaxHeadersPerRangeRequest }}
    RequestTimeout = "{{ .Values.node.config.full.configtoml.Header.Client.RequestTimeout }}"
[DASer]
  SamplingRange = {{ printf "%.0f" .Values.node.config.full.configtoml.DASer.SamplingRange }}
  ConcurrencyLimit = {{ printf "%.0f" .Values.node.config.full.configtoml.DASer.ConcurrencyLimit }}
  BackgroundStoreInterval = "{{ .Values.node.config.full.configtoml.DASer.BackgroundStoreInterval }}"
  SampleTimeout = "{{ .Values.node.config.full.configtoml.DASer.SampleTimeout }}"
  Enabled = {{ .Values.node.config.full.configtoml.DASer.Enabled }}
{{- end }}
